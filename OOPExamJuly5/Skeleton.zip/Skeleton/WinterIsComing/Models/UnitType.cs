﻿namespace WinterIsComing.Models
{
    public enum UnitType
    {
        Warrior,
        Mage,
        IceGiant
    }
}
